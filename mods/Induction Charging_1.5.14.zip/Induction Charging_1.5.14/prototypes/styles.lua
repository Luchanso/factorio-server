
data.raw["gui-style"].default["ic_stats"] = {
    type = "table_style",
    horizontal_spacing = 0,
    vertical_spacing = 0,
    max_on_row = 1,
    resize_row_to_width = true,
}

data.raw["gui-style"].default["ic_label"] = {
    type = "label_style",
    top_padding = 0,
    bottom_padding = 0,
    left_padding = 50,
    right_padding = 50,
}